#include "DJI_motor.h"

#include "CAN_receive.h"
#include "angle_process.h"
#include <string.h>

// ABS
#define ABS(X) ((X)>0?(X):(-X))

// �����������꺯��
#define IS_OUTPUT_ID_200H(id) ((id>=0x201)&&(id<=0x204))
#define IS_OUTPUT_ID_1FFH(id) ((id>=0x205)&&(id<=0x208))
#define GET_OUTPUT_CURRENT_INDEX(id) ((id-0x201)%4)

// Motor_Ctrl�꺯��
#define __DJI_Motor_Ctrl_get_reverse_current(motor_ptr,current) (motor_ptr->reverse_flag?-current:current)
#define __DJI_Motor_Ctrl_get_torque(motor_ptr) ((motor_ptr->recv_pack).torque)
#define __DJI_Motor_Ctrl_get_speed(motor_ptr) ((motor_ptr->recv_pack).speed_rpm)
#define __DJI_Motor_Ctrl_get_ecd(motor_ptr) ((motor_ptr->recv_pack).ecd)
#define __DJI_Motor_Ctrl_get_ecd_angle(motor_ptr) (motor_ptr->ecd_angle)
#define __DJI_Motor_Ctrl_get_angle(motor_ptr) ((motor_ptr->circle_count)*PI*2+*(motor_ptr->ref_ptr))
#define __DJI_Motor_Ctrl_get_init_state(motor_ptr,state_flag) ((motor_ptr->init_state)&(state_flag))
#define __DJI_Motor_Ctrl_set_init_state(motor_ptr,state_flag) ((motor_ptr->init_state)|=(state_flag))

#define __DJI_Motor_Ctrl_write_current(motor_ptr,current) \
  if(IS_OUTPUT_ID_200H(motor_ptr->id)) \
    (motor_ptr->mounted_bus->output_current200H)[GET_OUTPUT_CURRENT_INDEX(motor_ptr->id)]=__DJI_Motor_Ctrl_get_reverse_current(motor_ptr,current); \
  if(IS_OUTPUT_ID_1FFH(motor_ptr->id)) \
    (motor_ptr->mounted_bus->output_current1FFH)[GET_OUTPUT_CURRENT_INDEX(motor_ptr->id)]=__DJI_Motor_Ctrl_get_reverse_current(motor_ptr,current); \


/*�����Ƕȱ߽��ұ����ֵ(�ٶȣ�����)����߽���ȥʱ����*/
#define __DJI_Motor_Ctrl_boundary_ctrl(motor_ptr,detected_value) \
{ \
  if(__DJI_Motor_Ctrl_get_init_state(motor,MOTOR_ANGLE_LIMIT_INIT)) \
  { \
    if((motor->max_angle-motor->braking_angle)>__DJI_Motor_Ctrl_get_angle(motor) && \
    detected_value>0) \
      DJI_Motor_set_angle(motor,motor->max_angle); \
    else if((motor->min_angle+motor->braking_angle)<__DJI_Motor_Ctrl_get_angle(motor) && \
    detected_value<0) \
      DJI_Motor_set_angle(motor,motor->min_angle); \
  }  \
} \

void DJI_Motor_init(DJI_Motor_Ctrl_t* motor,DJI_Motor_Bus_t* bus,DJI_Motor_Type_e motor_type,uint16_t id)
{
  memset((void*)motor,0x0,sizeof(DJI_Motor_Ctrl_t));
  motor->type=motor_type;
  motor->id=id;
  motor->mounted_bus=bus;
  motor->ref_ptr=&(motor->ecd_angle);

  DJI_CANBus_add_motor(bus,motor);
  DJI_Motor_set_nonforce(motor);
}

/**
 * @brief �Ƕ���������
 * @param[in,out] motor ������ƾ��
 * @param[in] max_angle ���Ƕ�
 * @param[in] min_angle ��С�Ƕ�
 * @param[in] braking_angle �߽�ɲ���Ƕ�
 * @note ����(����)���ٶȿ���ʱ�����Ƕ���
 * max_angle-braking_angle ~ max_angle
 * ��min_angle ~ min_angle+braking_angle
 * �ķ�Χʱ������Ϊ��ֵ��λ�û�����
 */
void DJI_Motor_set_angle_limit(DJI_Motor_Ctrl_t* motor,fp32 max_angle,fp32 min_angle,fp32 braking_angle)
{
  if(motor==NULL)
    return;
  motor->max_angle=max_angle;
  motor->min_angle=min_angle;
  motor->braking_angle=braking_angle;
  __DJI_Motor_Ctrl_set_init_state(motor,MOTOR_ANGLE_LIMIT_INIT);
}

void DJI_Motor_set_speed_limit(DJI_Motor_Ctrl_t* motor,fp32 max_speed)
{
  motor->speed_limit=max_speed;
  __DJI_Motor_Ctrl_set_init_state(motor,MOTOR_SPEED_LIMIT_INIT);
}

void DJI_Motor_set_current_limit(DJI_Motor_Ctrl_t* motor,uint16_t max_current)
{
  motor->current_limit=max_current;
  __DJI_Motor_Ctrl_set_init_state(motor,MOTOR_CURRENT_LIMIT_INIT);
}

void inline DJI_Motor_set_reverse(DJI_Motor_Ctrl_t* motor)
{
  motor->reverse_flag=1;
}

/**
 * @brief �����ⲿ�Ƕȷ���
 */
void DJI_Motor_set_angle_feedback(DJI_Motor_Ctrl_t* motor,fp32* feedback_angle)
{
  motor->ref_ptr=feedback_angle;
  __DJI_Motor_Ctrl_set_init_state(motor,EXTERN_ENCODER_INIT);
}

/**
 * @brief ���λ�û�PID��ʼ��
 */
void DJI_Motor_Pos_PID_init(DJI_Motor_Ctrl_t* motor,enum PID_MODE pid_mode,
  fp32 Kp,fp32 Ki,fp32 Kd,
  fp32 max_out,fp32 max_iout)
{
  fp32 pid[3]={Kp,Ki,Kd};
  PID_Init(&(motor->pid_pos_loop),pid_mode,pid,max_out,max_iout,0.01,10);
  __DJI_Motor_Ctrl_set_init_state(motor,MOTOR_POS_PID_INIT);
}

/**
 * @brief ����ٶȻ�PID��ʼ��
 */
void DJI_Motor_Speed_PID_init(DJI_Motor_Ctrl_t* motor,enum PID_MODE pid_mode,
  fp32 Kp,fp32 Ki,fp32 Kd,
  fp32 max_out,fp32 max_iout)
{
  fp32 pid[3]={Kp,Ki,Kd};
  PID_Init(&(motor->pid_speed_loop),pid_mode,pid,max_out,max_iout,0.01,10);
  __DJI_Motor_Ctrl_set_init_state(motor,MOTOR_SPEED_PID_INIT);
}

void DJI_Motor_PID_set_deadband(DJI_Motor_Ctrl_t* motor,fp32 deadband)
{

}

inline void DJI_Motor_set_stall_detect(DJI_Motor_Ctrl_t* motor)
{
  __DJI_Motor_Ctrl_set_init_state(motor,MOTOR_STALL_DETECT_INIT);
}

void DJI_Motor_set_angle(DJI_Motor_Ctrl_t* motor, fp32 angle)
{
  if(!__DJI_Motor_Ctrl_get_init_state(motor,MOTOR_SPEED_PID_INIT|MOTOR_POS_PID_INIT))
  {
    __DJI_Motor_Ctrl_set_init_state(motor,NON_FORCE);
    return ;
  }

  if(__DJI_Motor_Ctrl_get_init_state(motor,MOTOR_ANGLE_LIMIT_INIT))
  {
    if(motor->max_angle<angle)
      angle=motor->max_angle;
    else if(motor->min_angle>angle)
      angle=motor->min_angle;
  }

  motor->mode=POS_LOOP;
  motor->set_angle=angle;
}

void DJI_Motor_set_speed(DJI_Motor_Ctrl_t* motor, fp32 speed_rpm)
{
  if(!__DJI_Motor_Ctrl_get_init_state(motor,MOTOR_SPEED_PID_INIT))
  {
    __DJI_Motor_Ctrl_set_init_state(motor,NON_FORCE);
    return ;
  }

  if(__DJI_Motor_Ctrl_get_init_state(motor,MOTOR_SPEED_LIMIT_INIT))
  {
    if(speed_rpm>motor->speed_limit)
      speed_rpm=motor->speed_limit;
    else if(speed_rpm<-motor->speed_limit)
      speed_rpm=-motor->speed_limit;
  }

  motor->mode=SPEED_LOOP;
  motor->set_speed=speed_rpm;
}

void DJI_Motor_set_current(DJI_Motor_Ctrl_t* motor, int16_t current)
{
  if(__DJI_Motor_Ctrl_get_init_state(motor,MOTOR_CURRENT_LIMIT_INIT))
  {
    if(current>motor->current_limit)
      current=motor->current_limit;
    else if(current<-motor->current_limit)
      current=-motor->current_limit;
  }

  motor->mode=GIVING_CURRENT;
  motor->set_current=current;
}

void DJI_Motor_set_nonforce(DJI_Motor_Ctrl_t* motor)
{
  motor->mode=NON_FORCE;
  motor->set_current=0x00;
}

void DJI_Motor_lockup(DJI_Motor_Ctrl_t* motor)
{
  if(!__DJI_Motor_Ctrl_get_init_state(motor,MOTOR_POS_PID_INIT|MOTOR_SPEED_PID_INIT))
  {
    __DJI_Motor_Ctrl_set_init_state(motor,NON_FORCE);
    return ;
  }

  motor->mode=LOCK;
  if(motor->set_lock_angle==0.0f)
    motor->set_lock_angle=__DJI_Motor_Ctrl_get_ecd_angle(motor);
}

/**
 * @brief ��ȡ������ֵ
 * @param[in]  motor  ������ƾ��
 * @param[out] torque ����/����
 * @param[out] speed  �ٶ�(rpm)
 * @param[out] angle  �Ƕ�(rad)
 */
void DJI_Motor_get_feedback(DJI_Motor_Ctrl_t* motor,fp32* torque,fp32* speed,fp32* angle)
{
  if(torque!=NULL)
    *torque=__DJI_Motor_Ctrl_get_torque(motor);
  if(speed!=NULL)
    *speed=__DJI_Motor_Ctrl_get_speed(motor);
  if(angle!=NULL)
    *angle=__DJI_Motor_Ctrl_get_angle(motor);
  return;
}

uint8_t DJI_Motor_get_stall_flag(DJI_Motor_Ctrl_t* motor)
{
  return motor->stall_flag;
}

void __DJI_Motor_speed_ctrl_loop(DJI_Motor_Ctrl_t* motor)
{
  if(!__DJI_Motor_Ctrl_get_init_state(motor,MOTOR_SPEED_PID_INIT))
  {
    __DJI_Motor_Ctrl_set_init_state(motor,NON_FORCE);
    return ;
  }


  __DJI_Motor_Ctrl_boundary_ctrl(motor,motor->set_speed);
  __DJI_Motor_Ctrl_write_current(motor,__DJI_Motor_speed_loop_calc(motor));
}

void __DJI_Motor_pos_ctrl_loop(DJI_Motor_Ctrl_t* motor)
{
  if((!__DJI_Motor_Ctrl_get_init_state(motor,MOTOR_SPEED_PID_INIT))||
  (!__DJI_Motor_Ctrl_get_init_state(motor,MOTOR_POS_PID_INIT)))
  {
    __DJI_Motor_Ctrl_set_init_state(motor,NON_FORCE);
    return ;
  }

  __DJI_Motor_Ctrl_write_current(motor,__DJI_Motor_angle_loop_calc(motor));
}

/**
 * @brief �����������ѭ��
 * �����ڶ�ʱ����ˢ�µ������
 */
void __DJI_Motor_current_ctrl_loop(DJI_Motor_Ctrl_t* motor)
{
  if(motor->mode!=LOCK)
    motor->set_lock_angle=0.0f;
  else
    motor->set_angle=motor->set_lock_angle;


  __DJI_Motor_Ctrl_boundary_ctrl(motor,motor->set_current);
  __DJI_Motor_Ctrl_write_current(motor,motor->set_current);
}

void __DJI_Motor_get_feedback(DJI_Motor_Ctrl_t* motor,uint8_t* rx_msg)
{
  //memcpy((void*)&(motor->recv_pack),rx_msg,sizeof(uint8_t)*8);//���ĸߵ�8λ�����෴������ֱ��memcpy
  // ���ĸ�ֵ
  motor->recv_pack.ecd=rx_msg[0]<<8;
  motor->recv_pack.ecd|=rx_msg[1];
  motor->recv_pack.speed_rpm=rx_msg[2]<<8;
  motor->recv_pack.speed_rpm|=rx_msg[3];
  motor->recv_pack.torque=rx_msg[4]<<8;
  motor->recv_pack.torque|=rx_msg[5];
  motor->recv_pack.temp=rx_msg[6];

  // ˢ�½Ƕ�ֵ
  motor->last_ecd_angle=motor->ecd_angle;
  motor->ecd_angle=NORMALIZE_TO_2PI(ecd_to_angle(motor->recv_pack.ecd,8191,0,0.0));

  // ������ת(������÷�ת)
  /*note: �ϵ�Ƕȿ��ܲ���0.0����Ҳ��֪����...*/
  if(motor->reverse_flag)
  {
    motor->recv_pack.speed_rpm  =  -motor->recv_pack.speed_rpm;
    motor->recv_pack.torque     =  -motor->recv_pack.torque;
    motor->ecd_angle=NORMALIZE_TO_2PI(angle_normalize(2*PI-motor->ecd_angle,0.0));
  }

  // ˢ��Ȧ��
  if(motor->circle_count_flag)
  {
    if(motor->ecd_angle>(2*PI*2/4)&&motor->last_ecd_angle<(2*PI*1/4))
    {
      motor->circle_count--;
    }
    else if(motor->last_ecd_angle>(2*PI*2/4)&&motor->ecd_angle<(2*PI*1/4))
    {
      motor->circle_count++;
    }
  }
}

static fp32 __DJI_Motor_speed_loop_calc(DJI_Motor_Ctrl_t* motor)
{
  return PID_Calc(&(motor->pid_speed_loop),__DJI_Motor_Ctrl_get_speed(motor),motor->set_speed);
}

static fp32 __DJI_Motor_angle_loop_calc(DJI_Motor_Ctrl_t* motor)
{
  fp32 output_speed=0.0f;

  if(motor->circle_count_flag)
  {
    output_speed=PID_Calc(
      &(motor->pid_pos_loop),
      __DJI_Motor_Ctrl_get_angle(motor),
      motor->set_angle
    );
  }
  else
  {
    output_speed=PID_Calc(
      &(motor->pid_pos_loop),
      0,
      angle_normalize(motor->set_angle,-__DJI_Motor_Ctrl_get_angle(motor))
    );
  }

  /*��ת���*/
  if(__DJI_Motor_Ctrl_get_init_state(motor,MOTOR_STALL_DETECT_INIT))
  {
    if(motor->stall_flag==0)
    {
      if(ABS((float)__DJI_Motor_Ctrl_get_speed(motor))<output_speed*0.2f && output_speed>15.0f)
      {
        motor->start_stall_time++;
      }
      else
      {
        motor->start_stall_time=0;
      }

      if(motor->start_stall_time==3000)
      {
        motor->stall_flag=1;
        motor->start_stall_time=0;
      }
    }
    else
    {
      motor->start_stall_time++;
      output_speed=0.0f;
      if(motor->start_stall_time>1000)
      {
        motor->start_stall_time=0;
        motor->stall_flag=0;
      }
    }
  }

  return PID_Calc(&(motor->pid_speed_loop),
    __DJI_Motor_Ctrl_get_speed(motor),
    output_speed
  );
}

